package com.infinite.repository;

import java.util.List;

import com.infinite.model.User;

public interface IAdminuserlistDao {
	
	public List<User> getUsers();

}
